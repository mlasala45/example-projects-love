return {
	w = 63,
	h = 63,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 63,
			h = 63,
		}
	}
}