return {
	w = 188,
	h = 189,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 188,
			h = 189,
		}
	}
}