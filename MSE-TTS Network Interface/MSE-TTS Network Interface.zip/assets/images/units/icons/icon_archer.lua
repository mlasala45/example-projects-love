return {
	w = 36,
	h = 36,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 36,
			h = 36,
		}
	}
}