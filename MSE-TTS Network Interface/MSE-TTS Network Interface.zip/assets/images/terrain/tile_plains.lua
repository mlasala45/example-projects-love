return {
	w = 1678,
	h = 1678,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 1678,
			h = 1678,
		}
	}
}