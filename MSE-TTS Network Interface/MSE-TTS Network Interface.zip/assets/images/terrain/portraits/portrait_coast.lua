return {
	w = 256,
	h = 256,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 256,
			h = 256,
		}
	}
}