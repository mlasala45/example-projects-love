return {
	w = 225,
	h = 225,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 225,
			h = 225,
		}
	}
}