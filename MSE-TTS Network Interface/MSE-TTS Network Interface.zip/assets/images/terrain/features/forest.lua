return {
	w = 200,
	h = 200,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 200,
			h = 200,
		}
	}
}