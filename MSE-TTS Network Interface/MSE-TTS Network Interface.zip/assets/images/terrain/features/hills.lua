return {
	w = 124,
	h = 50,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 124,
			h = 50,
		}
	}
}