return {
	w = 115,
	h = 44,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 115,
			h = 44,
		}
	}
}