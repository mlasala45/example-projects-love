return {
	w = 2048,
	h = 2048,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 2048,
			h = 2048,
		}
	}
}