return {
	w = 52,
	h = 51,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 52,
			h = 51,
		}
	}
}