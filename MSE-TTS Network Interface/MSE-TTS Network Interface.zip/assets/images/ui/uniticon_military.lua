return {
	w = 72,
	h = 72,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 72,
			h = 72,
		}
	}
}