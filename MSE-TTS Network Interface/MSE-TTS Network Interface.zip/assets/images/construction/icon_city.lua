return {
	w = 512,
	h = 512,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 512,
			h = 512,
		}
	}
}