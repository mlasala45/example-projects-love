return {
	w = 39,
	h = 40,

	textures = {
		tex = {
			x = 0,
			y = 0,
			w = 39,
			h = 40,
		}
	}
}