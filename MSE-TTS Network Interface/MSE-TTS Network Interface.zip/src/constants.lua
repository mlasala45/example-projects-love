require "util/color"

--Window Parameters and Engine Graphics
FULLSCREEN = true
WINDOW_WIDTH = 2000*0.4
WINDOW_HEIGHT = 1374*0.4
MSAA = 4

--Debug Flags
DEBUG = true

--Colors
DEBUG_COLOR = COLORS.WHITE
DEBUG_TEXT_COLOR = COLORS.WHITE