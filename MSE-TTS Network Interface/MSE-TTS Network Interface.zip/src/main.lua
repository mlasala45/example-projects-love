require "constants"
require "strings"
require "tuning"

debug_str = ""
p_debug_str = ""

print = function(msg)
	msg = msg or ""
	debug_str = debug_str..tostring(msg).."\n"
end

--Persistent
p_print = function(msg)
	msg = msg or ""
	p_debug_str = p_debug_str..tostring(msg).."\n"
end

p_clear = function()
	p_debug_str = ""
end

clear = function()
	debug_str = ""
end

function love.load()
	math.randomseed(os.time())
	
	love.window.setTitle(STRINGS.WINDOW_TITLE)
	love.window.setMode(WINDOW_WIDTH, WINDOW_HEIGHT, { fullscreen=FULLSCREEN, msaa=MSAA })
	WINDOW_WIDTH = love.graphics.getWidth()
	WINDOW_HEIGHT = love.graphics.getHeight()

	MID_X = WINDOW_WIDTH / 2
	MID_Y = WINDOW_HEIGHT / 2

    love.filesystem.mount(love.filesystem.getSourceBaseDirectory(),"base")
    p_print(love.filesystem.getSaveDirectory())

    local myFont = love.graphics.newFont( "assets/fonts/arial.ttf", 8 )
	myFont:setFilter( "nearest", "nearest" )
	love.graphics.setFont(myFont)


	--Init
	
	p_print("Init Complete: "..tostring(os.time()))
end

function love.keypressed(key,scancode,isrepeat)
	if key=="escape" then
		love.event.quit()
	end

	--
end

function love.mousepressed(x, y, button, istouch)
	--
end

function love.update(dt)
	--time_acc = time_acc + dt

	clear()
	print("FPS "..love.timer.getFPS())

	--Update

	--
end

function love.draw()
	--

	if DEBUG then
		love.graphics.setColor(DEBUG_TEXT_COLOR)
		love.graphics.print(debug_str..p_debug_str, 0, 0)
		love.graphics.setColor(COLORS.WHITE)
	end
end