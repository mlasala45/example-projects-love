STRINGS = {
	WINDOW_TITLE = "Hacking",

	--

	UI = {
		NOTIFICATIONS = {
			DEFAULT_TEXT = "Notification Text",

			--
		},
	},

	DESC = {
		--
	},
}